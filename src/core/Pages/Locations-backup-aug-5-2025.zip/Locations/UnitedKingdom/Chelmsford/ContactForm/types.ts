// src/core/Pages/Locations/UnitedKingdom/Chelmsford/ContactForm/types.ts
export type NotificationType = "success" | "error" | "info" | "warning";

export interface NotificationState {
  isVisible: boolean;
  type: NotificationType;
  title: string;
  message: string;
}

export interface ChelmsfordFormData {
  name: string;
  email: string;
  phone: string;
  message: string;
  type: string;
}

// Updated to include the 'body' property that might be in the API response
export interface ChelmsfordFormResponse {
  success: boolean;
  message: string;
  formID?: string;
}

// Adding a type for the Lambda proxy response which includes body
export interface LambdaProxyResponse {
  statusCode?: number;
  body?: string | any;
  headers?: Record<string, string>;
  success?: boolean;
  message?: string;
  formID?: string;
}
