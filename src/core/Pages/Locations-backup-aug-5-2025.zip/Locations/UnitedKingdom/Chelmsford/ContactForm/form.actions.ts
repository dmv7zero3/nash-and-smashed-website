// src/core/Pages/Locations/UnitedKingdom/Chelmsford/ContactForm/form.actions.ts
import axios, { AxiosResponse } from "axios";
import {
  ChelmsfordFormData,
  ChelmsfordFormResponse,
  LambdaProxyResponse,
} from "./types";
import { api, ENDPOINTS } from "@/core/api/apiClient";

// Helper to create a minimum request time for better UX
const withMinRequestTime = <T>(
  promise: Promise<T>,
  minTime = 1000
): Promise<T> => {
  const timeoutPromise = new Promise<void>((resolve) => {
    setTimeout(() => resolve(), minTime);
  });

  return Promise.all([promise, timeoutPromise]).then(([result]) => result);
};

export const submitChelmsfordContactForm = async (
  formData: ChelmsfordFormData
): Promise<ChelmsfordFormResponse> => {
  try {
    // Create a promise for the API request but ensure it takes at least 1 second
    const response = await withMinRequestTime<
      AxiosResponse<LambdaProxyResponse | ChelmsfordFormResponse>
    >(
      api.post(ENDPOINTS.FORMS.CONTACT, {
        // Map the Chelmsford form fields to the expected API fields
        firstName: formData.name.split(" ")[0] || formData.name,
        lastName: formData.name.split(" ").slice(1).join(" ") || "",
        email: formData.email,
        phone: formData.phone,
        interestType: formData.type,
        message: formData.message,
        location: "Chelmsford, UK",
      })
    );

    console.log("API response:", response); // Debug log

    // Handle Lambda proxy integration response format
    if (response.data && "body" in response.data) {
      try {
        // If body is a string, parse it
        const bodyData =
          typeof response.data.body === "string"
            ? JSON.parse(response.data.body)
            : response.data.body;

        return {
          success: bodyData.success,
          message:
            bodyData.message || "Your message has been successfully submitted.",
          formID: bodyData.formID,
        };
      } catch (parseError) {
        console.error("Error parsing response body:", parseError);
        // If we can't parse the body, check if the response itself was successful
        return {
          success: response.status === 200,
          message:
            "Your message has been submitted, but we encountered an issue processing the response.",
          formID: "UNKNOWN",
        };
      }
    }

    // Check if the response has a data property with a success field
    if (response.data) {
      return {
        success:
          "success" in response.data
            ? !!response.data.success // <-- Ensure boolean
            : response.status === 200,
        message:
          ("message" in response.data && response.data.message) ||
          "Your message has been successfully submitted.",
        formID: "formID" in response.data ? response.data.formID : "UNKNOWN",
      };
    }

    // If we got a response but no structured data, assume success
    return {
      success: true,
      message: "Your message has been submitted successfully.",
      formID: "UNKNOWN",
    };
  } catch (error) {
    console.error("Error submitting contact form:", error);

    if (axios.isAxiosError(error) && error.response) {
      console.error("Error details:", {
        status: error.response.status,
        statusText: error.response.statusText,
        data: error.response.data,
        headers: error.response.headers,
      });

      // Return the error message from the API if available
      return {
        success: false,
        message:
          (error.response.data?.message as string) ||
          "Failed to submit your message. Please try again later.",
      };
    }

    // Generic error message
    return {
      success: false,
      message:
        "Network error occurred. Please check your connection and try again.",
    };
  }
};
